package de.Telran.lesson2;

public class HomeTask1 {

    public static void main(String[] args) {
        char j ='G';
        int l = 89;
        byte i = 4;
        short u = 56;
        float p = 4.7333436f;
        double g = 4.355453532;
        long v = 12122;
        System.out.println("char: " + j);
        System.out.println("int: " + l);
        System.out.println("byte: " + i);
        System.out.println("short: " + u);
        System.out.println("float: " + p);
        System.out.println("double: " + g);
        System.out.println("long: " + v);
    }
}
