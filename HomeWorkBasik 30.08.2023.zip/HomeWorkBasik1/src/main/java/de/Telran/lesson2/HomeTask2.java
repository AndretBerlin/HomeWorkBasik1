package de.Telran.lesson2;

public class HomeTask2 {
    public static void main(String[] args) {
        int x = 345;
        int y = x / 100;
        int u = x % 100 / 10;
        int i = x % 10;
        char r = ',';
        System.out.println("число: "+ x + " -> " + y + r + u + r + i);


            int a = 987;
            int b = a / 100;
            int n= a % 100 / 10;
            int m = a% 10;
            char k = ',';
            System.out.println("число: "+ a + " -> " + b + k + n + k + m + k);}

        }

