package de.Telran.lesson2;

public class HomeTask3 {
    public static void main(String[] args) {

        System.out.printf("Уважаемый %s, свои %d лет, Вы для нас дороги как %.2f кг золота!","Адрей",45,90.0 );
    }
}
